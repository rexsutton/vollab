/* This is file was generated automatically at 2014-11-01 at 14:47:05. Please do not edit. */
#define REVISION         990
#define VERSION   "1.0.0.990"
#define COPYRIGHT "� 2013-2014 Peter J�ckel"
