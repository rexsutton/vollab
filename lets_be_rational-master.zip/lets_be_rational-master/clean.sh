rm *.o
rm src/LetsBeRational_wrap.c
rm lets_be_rational/LetsBeRational.py
rm lets_be_rational/*.pyc
rm lets_be_rational/*.so
rm lets_be_rational/*.pyd
rm -rf build
rm -rf dist
rm -rf *.egg*
